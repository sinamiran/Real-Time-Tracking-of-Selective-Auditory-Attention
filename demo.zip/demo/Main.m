close all;
clear variables;
clc;

% This file reproduces the simulation results of case 2 in Figure 4 of the
% paper "Real-Time Tracking of Selective Auditory Attention from M/EEG: A 
% Bayesian Filtering Approach" by Miran et al. The parameters are set as 
% explained in the paper. This code uses the fasta.m function available in
% FASTA package [1] for implementing the Forward-Backward Splitting method
% , which has been included in the folder for convenience.

% [1] https://www.cs.umd.edu/~tomg/projects/fasta/

%% Constructing the Auditory Response through the Forward Model

% setting the Parameters

fs = 200; % sampling rate
T = 60*fs; % trial length
L = floor(0.4*fs)+1; % FIR impulse response length of 0.4s
n_std = 5e-3; % Gaussian noise standard deviation
mu = 2e-2; % constant mean

% loading speech envelopes

env = zeros(T,2);
load Env1_200;
env(:,1) = Env;
load Env2_200;
env(:,2) = Env;

% constructing the impulse response h(t)

h_sparse = zeros(L,1);
h_sparse(floor(0.05*fs)+1) = 6e-3;
h_sparse(floor(0.1*fs)+1) = -6e-3;
h_sparse(floor(0.15*fs)+1) = -1.8e-3;
h_sparse(floor(0.25*fs)+1) = 1.5e-3;
h_sparse(floor(0.35*fs)+1) = 1e-3;

% smoothing Gaussian kernel for the impulse response
std_ker = 0.01;
t = -5*std_ker:1/fs:5*std_ker;
kernel = 1/(std_ker*sqrt(2*pi))*exp(-t.^2/(2*std_ker^2));
t = -5*std_ker:1/fs:5*std_ker;
R = length(find(t<0));
G = zeros(2*R+L-1,L);
for i = 1:L
    G(i:i+length(kernel)-1,i) = kernel';
end
G = G(R+1:R+L,:);

h_smooth = G*h_sparse; % smoothed impulse response h(t)

figure;
% figure('pos',[100 100 500 600]);
subplot(2,1,1)
stem((0:L-1)/fs,h_sparse,'Marker','none','LineWidth',1.5);
ylim([-0.007 0.007])
title('impulse response h(t) in its sparse domain');
xlabel('time (s)');
grid on;
subplot(2,1,2)
plot((0:L-1)/fs,h_smooth,'LineWidth',1.5);
ylim([-0.3 0.3])
title('smoothed impulse respones h(t) through applying a Gaussian kernel')
xlabel('time (s)');
grid on;

% constructing the weight vectors w_1(t) and w_2(t) for the auditory 
% response of speakers 1 and 2

% weight vector parameters
low = 0.6;
high = 0.9;
mag = 0.02;

ind = ceil(1.5*fs);
w1 = zeros(T,1);
w2 = zeros(T,1);
w1(1:ceil(T/2)) = high + mag*randn(ceil(T/2),1);
w1(ceil(T/2)+1:end) = low + mag*randn(T-ceil(T/2),1);
w2(1:ceil(T/2)) = low + mag*randn(ceil(T/2),1);
w2(ceil(T/2)+1:end) = high + mag*randn(T-ceil(T/2),1);
w1(ceil(T/2)-ind:ceil(T/2)+ind) = linspace(high,low,2*ind+1)' + mag*randn(2*ind+1,1);
w2(ceil(T/2)-ind:ceil(T/2)+ind) = linspace(low,high,2*ind+1)' + mag*randn(2*ind+1,1);

figure;
plot((0:T-1)/fs,w1,'g',(0:T-1)/fs,w2,'r');
legend('w_1(t)','w_2(t)','Location','southeast')
title('weight vecotrs w_1(t) and w_2(t) for the auditory response of speakers 1 and 2');
axis tight;
xlabel('time (s)');
xlim([0 60])
ylim([0 1.1])
grid on;

% constructing the auditory response e(t)

X1 = toeplitz(env(:,1),zeros(1,L));
X2 = toeplitz(env(:,2),zeros(1,L));

aud1 = X1*h_smooth; % auditory response of speaker 1
aud2 = X2*h_smooth; % auditory response of speaker 2

aud = w1.*aud1 + w2.*aud2 + mu + n_std*randn(T,1); % mixed auditory response

figure('pos',[100 100 700 650]);
subplot(3,1,1)
plot((1:T)/fs,aud1);
title('auditory response of speaker 1')
xlabel('time (s)')
ylim([-0.2 0.2]);
subplot(3,1,2)
plot((1:T)/fs,aud2);
title('auditory response of speaker 2')
xlabel('time (s)')
ylim([-0.2 0.2]);
subplot(3,1,3)
plot((1:T)/fs,aud);
title('mixed auditory response with noise and mean')
xlabel('time (s)')
ylim([-0.2 0.2]);

%% Real-Time Decoding of the Attentional State from the Auditory Response

% setting the decoder estimation parameters
L = floor(0.4*fs)+1; % decoder lag
T = T-L+1; % effective data length for estimation
W = floor(0.25*fs); % considering consecutive windows of length 250ms
K = floor(T/W); % number of windows, i.e. instances
lambda = 1 - W/(5*fs); % forgetting factor with the effective estimation length of 5s
gamma = 1e-3; % l1 regularization parameter
c = 1e-1;

% setting the parameters of FASTA package for efficient FBS implementation
g = @(x) norm(x,1)*gamma;
proxg = @(x,t) sign(x).*max(abs(x) - t*gamma,0);
opts = [];
opts.maxIters = 1000;
opts.tol = 1e-3;
opts.verbose = true;
opts.accelerate = true;
opts.adaptive = false;
opts.restart = true;
opts.stringHeader='    ';

X = toeplitz(aud(L:end),flipud(aud(1:L)));
X = fliplr(X); 
cov = [c*ones(T,1) X]; % covariance matrix X in decoder estimation
Y1 = env(:,1);
Y2 = env(:,2);

Dec1 = zeros(L+1,K); % estimated decoder for speaker 1
Dec2 = zeros(L+1,K); % estimated decoder for speaker 2

A = zeros(L+1,L+1);
b1 = zeros(1,L+1);
b2 = zeros(1,L+1);

% variables for storing attentional marker outputs
c1 = zeros(K,1); % correlation-based attentional marker outputs for speaker 1
c2 = zeros(K,1); % correlation-based attentional marker outputs for speaker 2
m1 = zeros(K,1); % l1-based attentional marker outputs for speaker 1
m2 = zeros(K,1); % l1-based attentional marker outputs for speaker 2
th = 1e-14;

% setting the parameters of the batch and dynamic state-space models

outer_EM_dynamic = 20;
inner_EM_dynamic = 1;
Newton_iter = 10;

c0 = 1.65; % for %90 confidence intervals

% parameters of the inverse-gamma prior on state-space variances
mean_p = 0.2;
var_p = 5;
a_0 = 2+mean_p^2/var_p;
b_0 = mean_p*(a_0-1);

% parameters of the fixed-lag sliding window
K_F = floor(1.5*fs/W); % forward-lag
K_B = floor(13.5*fs/W); % backward_lag
K_W = K_F + K_B + 1; % window-length
lambda_state = 1;

% dynamic state-space model outputs for the two attentional markers
z_dyn_c = zeros(K,1); % _c: correlation-based
eta_dyn_c = zeros(K,1);
z_dyn_l = zeros(K,1); % _l: l1_based
eta_dyn_l = zeros(K,1);

z_smoothed_c = zeros(K,1);
eta_smoothed_c = 0.3*ones(K,1);
z_smoothed_l = zeros(K,1);
eta_smoothed_l = 0.3*ones(K,1);

% Kalman filtering and smoothing variables
z_k_k_c = zeros(K_W+1,1);
z_k_k_1_c = zeros(K_W+1,1);
sig_k_k_c = zeros(K_W+1,1);
sig_k_k_1_c = zeros(K_W+1,1);
z_k_k_l = zeros(K_W+1,1);
z_k_k_1_l = zeros(K_W+1,1);
sig_k_k_l = zeros(K_W+1,1);
sig_k_k_1_l = zeros(K_W+1,1);

z_k_K_c = zeros(K_W+1,1);
sig_k_K_c = zeros(K_W+1,1);
z_k_K_l = zeros(K_W+1,1);
sig_k_K_l = zeros(K_W+1,1);

S_c = zeros(K_W,1);
S_l = zeros(K_W,1);

% tuned attended and unattended prior distributions based on a similar trial
alpha_0_c = [6.4113e+02;4.0434e+03];
beta_0_c = [3.7581e+02;6.2791e+03];
mu_0_c = [-0.3994;-1.5103];
alpha_0_l = [5.7111e+02;1.7725e+03];
beta_0_l = [34.96324;2.1424e+02];
mu_0_l = [0.88897;0.1619];

% initialized attended and unattended Log-Normal distribution parameters
% based on a similar trial
rho_d_0_c = [1.7060;0.64395];
mu_d_0_c = [-0.3994;-1.5103];
rho_d_0_l = [16.3344;8.2734];
mu_d_0_l = [0.88897;0.16195];

figure('pos',[100 100 700 650]);
subplot(2,1,1)
x = linspace(0,2,1000);
plot(x,(1./x)*sqrt(rho_d_0_c(1)).*exp(-0.5*rho_d_0_c(1)*((log(x)-mu_d_0_c(1)).^2)),'g','LineWidth',1.5);
hold on;
plot(x,(1./x)*sqrt(rho_d_0_c(2)).*exp(-0.5*rho_d_0_c(2)*((log(x)-mu_d_0_c(2)).^2)),'r','LineWidth',1.5);
hold off;
title('initialized Log-Normal distributions for the correlation-based attentional marker');
legend('attended','unattended');
subplot(2,1,2)
x = linspace(0,6,1000);
plot(x,(1./x)*sqrt(rho_d_0_l(1)).*exp(-0.5*rho_d_0_l(1)*((log(x)-mu_d_0_l(1)).^2)),'g','LineWidth',1.5);
hold on;
plot(x,(1./x)*sqrt(rho_d_0_l(2)).*exp(-0.5*rho_d_0_l(2)*((log(x)-mu_d_0_l(2)).^2)),'r','LineWidth',1.5);
hold off;
title('initialized Log-Normal distributions for the l_1-based attentional marker');
legend('attended','unattended');

rho_d_l = rho_d_0_l;
mu_d_l = mu_d_0_l;
rho_d_c = rho_d_0_c;
mu_d_c = mu_d_0_c;

for k = 1:K
    
    % estimating the decoder coefficients at instance k through FBS
    
    A = lambda*A + cov((k-1)*W+1:k*W,:)'*cov((k-1)*W+1:k*W,:);
    b1 = lambda*b1 + Y1((k-1)*W+1:k*W)'*cov((k-1)*W+1:k*W,:);
    b2 = lambda*b2 + Y2((k-1)*W+1:k*W)'*cov((k-1)*W+1:k*W,:);

    if k == 1
        init1 = zeros(L+1,1);
        init2 = zeros(L+1,1);
    else
        init1 = Dec1(:,k-1);
        init2 = Dec2(:,k-1);
    end
    
    [Dec1(:,k),~] = fasta( @(x) x, @(x) x, @(x) x'*A*x-2*b1*x, @(x) 2*A*x-2*b1', g, proxg, init1, opts);
    [Dec2(:,k),~] = fasta( @(x) x, @(x) x, @(x) x'*A*x-2*b2*x, @(x) 2*A*x-2*b2', g, proxg, init2, opts);

    % calculating the attentional marker outputs at instance k for each speaker
    
    % correlation-based attentional marker
    rec1 = cov((k-1)*W+1:k*W,:)*Dec1(:,k);
    rec2 = cov((k-1)*W+1:k*W,:)*Dec2(:,k);
    if var(rec1)>th
        E = corrcoef(rec1,Y1((k-1)*W+1:k*W));
        c1(k) = max( abs(E(1,2)) , 1e-4 );
    end
    if var(rec2)>th
        E = corrcoef(rec2,Y2((k-1)*W+1:k*W));
        c2(k) = max( abs(E(1,2)) , 1e-4 );
    end

    % l1_based attentional marker
    m1(k) = max( norm(Dec1(2:end,k),1) , 1e-4 );
    m2(k) = max( norm(Dec2(2:end,k),1) , 1e-4 );
    
    % applying the dynamic state-space model
    
    if k >= K_W % starting the dynamic state-space starting from K_W samples
        
        c1_w = c1(k-K_W+1:k);
        c2_w = c2(k-K_W+1:k);
        m1_w = m1(k-K_W+1:k);
        m2_w = m2(k-K_W+1:k);
        z_c = z_smoothed_c(k-K_W+1:k);
        z_l = z_smoothed_l(k-K_W+1:k);
        eta_c = eta_smoothed_c(k-K_W+1:k);
        eta_l = eta_smoothed_l(k-K_W+1:k);
        
        % outer EM
        for i = 1:outer_EM_dynamic
            
            % calculating epsilon_k's in the current iteration (E-Step)
            
            P_11_c = (1./c1_w)*sqrt(rho_d_c(1)).*exp(-0.5*rho_d_c(1)*(log(c1_w)-mu_d_c(1)).^2);
            P_12_c = (1./c1_w)*sqrt(rho_d_c(2)).*exp(-0.5*rho_d_c(2)*(log(c1_w)-mu_d_c(2)).^2);
            P_21_c = (1./c2_w)*sqrt(rho_d_c(2)).*exp(-0.5*rho_d_c(2)*(log(c2_w)-mu_d_c(2)).^2);
            P_22_c = (1./c2_w)*sqrt(rho_d_c(1)).*exp(-0.5*rho_d_c(1)*(log(c2_w)-mu_d_c(1)).^2);
            
            P_11_l = (1./m1_w)*sqrt(rho_d_l(1)).*exp(-0.5*rho_d_l(1)*(log(m1_w)-mu_d_l(1)).^2);
            P_12_l = (1./m1_w)*sqrt(rho_d_l(2)).*exp(-0.5*rho_d_l(2)*(log(m1_w)-mu_d_l(2)).^2);
            P_21_l = (1./m2_w)*sqrt(rho_d_l(2)).*exp(-0.5*rho_d_l(2)*(log(m2_w)-mu_d_l(2)).^2);
            P_22_l = (1./m2_w)*sqrt(rho_d_l(1)).*exp(-0.5*rho_d_l(1)*(log(m2_w)-mu_d_l(1)).^2);
            
            p_c = squeeze(1./(1+exp(-z_c)));
            p_l = squeeze(1./(1+exp(-z_l)));
            
            E_c = (p_c.*P_11_c.*P_21_c)./(p_c.*P_11_c.*P_21_c+(1-p_c).*P_12_c.*P_22_c);
            E_l = (p_l.*P_11_l.*P_21_l)./(p_l.*P_11_l.*P_21_l+(1-p_l).*P_12_l.*P_22_l);
            
            % distribution parameters update (M-Step)
            
            mu_d_c(1) = ( sum(E_c.*log(c1_w)+(1-E_c).*log(c2_w)) + K_W*mu_0_c(1) )/(2*K_W);
            mu_d_c(2) = ( sum(E_c.*log(c2_w)+(1-E_c).*log(c1_w)) + K_W*mu_0_c(2) )/(2*K_W);
            rho_d_c(1) = (2*K_W*alpha_0_c(1))/( sum( E_c.*((log(c1_w)-mu_d_c(1)).^2) + (1-E_c).*((log(c2_w)-mu_d_c(1)).^2) ) + K_W*(2*beta_0_c(1)+(mu_d_c(1)-mu_0_c(1)).^2) );
            rho_d_c(2) = (2*K_W*alpha_0_c(2))/( sum( E_c.*((log(c2_w)-mu_d_c(2)).^2) + (1-E_c).*((log(c1_w)-mu_d_c(2)).^2) ) + K_W*(2*beta_0_c(2)+(mu_d_c(2)-mu_0_c(2)).^2) );

            mu_d_l(1) = ( sum(E_l.*log(m1_w)+(1-E_l).*log(m2_w)) + K_W*mu_0_l(1) )/(2*K_W);
            mu_d_l(2) = ( sum(E_l.*log(m2_w)+(1-E_l).*log(m1_w)) + K_W*mu_0_l(2) )/(2*K_W);
            rho_d_l(1) = (2*K_W*alpha_0_l(1))/( sum( E_l.*((log(m1_w)-mu_d_l(1)).^2) + (1-E_l).*((log(m2_w)-mu_d_l(1)).^2) ) + K_W*(2*beta_0_l(1)+(mu_d_l(1)-mu_0_l(1)).^2) );
            rho_d_l(2) = (2*K_W*alpha_0_l(2))/( sum( E_l.*((log(m2_w)-mu_d_l(2)).^2) + (1-E_l).*((log(m1_w)-mu_d_l(2)).^2) ) + K_W*(2*beta_0_l(2)+(mu_d_l(2)-mu_0_l(2)).^2) );
            
            % inner EM for updating z's and eta's (M-Step)
            
            for j = 1:inner_EM_dynamic
                
                % Filtering
                for kk = 2:K_W+1
                    
                    z_k_k_1_c(kk) = lambda_state*z_k_k_c(kk-1);
                    sig_k_k_1_c(kk) = lambda_state^2*sig_k_k_c(kk-1) + eta_c(kk-1);
                    z_k_k_1_l(kk) = lambda_state*z_k_k_l(kk-1);
                    sig_k_k_1_l(kk) = lambda_state^2*sig_k_k_l(kk-1) + eta_l(kk-1);
                    
                    % Newton's Algorithm
                    for m=1:Newton_iter
                        z_k_k_c(kk) = z_k_k_c(kk) - (z_k_k_c(kk) - z_k_k_1_c(kk) - sig_k_k_1_c(kk)*(E_c(kk-1) - exp(z_k_k_c(kk))/(1+exp(z_k_k_c(kk))))) / (1 + sig_k_k_1_c(kk)*exp(z_k_k_c(kk))/((1+exp(z_k_k_c(kk)))^2));
                        z_k_k_l(kk) = z_k_k_l(kk) - (z_k_k_l(kk) - z_k_k_1_l(kk) - sig_k_k_1_l(kk)*(E_l(kk-1) - exp(z_k_k_l(kk))/(1+exp(z_k_k_l(kk))))) / (1 + sig_k_k_1_l(kk)*exp(z_k_k_l(kk))/((1+exp(z_k_k_l(kk)))^2));
                    end
                    
                    sig_k_k_c(kk) = 1 / (1/sig_k_k_1_c(kk) + exp(z_k_k_c(kk))/((1+exp(z_k_k_c(kk)))^2));
                    sig_k_k_l(kk) = 1 / (1/sig_k_k_1_l(kk) + exp(z_k_k_l(kk))/((1+exp(z_k_k_l(kk)))^2));
                    
                end
                
                % Smoothing
                z_k_K_c(K_W+1) = z_k_k_c(K_W+1);
                sig_k_K_c(K_W+1) = sig_k_K_c(K_W+1);
                z_k_K_l(K_W+1) = z_k_k_l(K_W+1);
                sig_k_K_l(K_W+1) = sig_k_K_l(K_W+1);
                
                for kk = K_W:-1:1
                    
                    S_c(kk) = sig_k_k_c(kk)*lambda_state/sig_k_k_1_c(kk+1);
                    z_k_K_c(kk) = z_k_k_c(kk) + S_c(kk)*(z_k_K_c(kk+1) - z_k_k_1_c(kk+1));
                    sig_k_K_c(kk) = sig_k_k_c(kk) + S_c(kk)^2*(sig_k_K_c(kk+1) - sig_k_k_1_c(kk+1));
                    
                    S_l(kk) = sig_k_k_l(kk)*lambda_state/sig_k_k_1_l(kk+1);
                    z_k_K_l(kk) = z_k_k_l(kk) + S_l(kk)*(z_k_K_l(kk+1) - z_k_k_1_l(kk+1));
                    sig_k_K_l(kk) = sig_k_k_l(kk) + S_l(kk)^2*(sig_k_K_l(kk+1) - sig_k_k_1_l(kk+1));
                    
                end
                
                z_k_k_c(1) = z_k_K_c(1);
                sig_k_k_c(1) = sig_k_K_c(1);
                
                z_k_k_l(1) = z_k_K_l(1);
                sig_k_k_l(1) = sig_k_K_l(1);
                
                eta_c = ( (z_k_K_c(2:end)-z_k_K_c(1:end-1)).^2+sig_k_K_c(2:end)+sig_k_K_c(1:end-1)-2*sig_k_K_c(2:end).*S_c+2*b_0 )/(1+2*(a_0+1));
                eta_l = ( (z_k_K_l(2:end)-z_k_K_l(1:end-1)).^2+sig_k_K_l(2:end)+sig_k_K_l(1:end-1)-2*sig_k_K_l(2:end).*S_l+2*b_0 )/(1+2*(a_0+1));
                
            end
            
            z_c = z_k_K_c(2:end);
            z_l = z_k_K_l(2:end);
            
        end
        
        % update the z's and eta's
        
        z_smoothed_c(k-K_W+1:k) = z_k_K_c(2:end);
        eta_smoothed_c(k-K_W+1:k) = eta_c;
        z_k_k_c(1) = z_k_K_c(2);
        z_dyn_c(k-K_F) = z_smoothed_c(k-K_F);
        eta_dyn_c(k-K_F) = eta_smoothed_c(k-K_F);
        
        z_smoothed_l(k-K_W+1:k) = z_k_K_l(2:end);
        eta_smoothed_l(k-K_W+1:k) = eta_l;
        z_k_k_l(1) = z_k_K_l(2);
        z_dyn_l(k-K_F) = z_smoothed_l(k-K_F);
        eta_dyn_l(k-K_F) = eta_smoothed_l(k-K_F);
        
        if k == K_W
            
            z_dyn_c(1:K_B) = z_smoothed_c(1:K_B);
            eta_dyn_c(1:K_B) = eta_smoothed_c(1:K_B);
            
            z_dyn_l(1:K_B) = z_smoothed_l(1:K_B);
            eta_dyn_l(1:K_B) = eta_smoothed_l(1:K_B);
          
        end    
            
        if k == K
            
            z_dyn_c(k-K_F+1:end) = z_smoothed_c(k-K_F+1:end);
            eta_dyn_c(k-K_F+1:end) = eta_smoothed_c(k-K_F+1:end);
            
            z_dyn_l(k-K_F+1:end) = z_smoothed_l(k-K_F+1:end);
            eta_dyn_l(k-K_F+1:end) = eta_smoothed_l(k-K_F+1:end);
        
        end    
        
        if k < K
            
            z_smoothed_c(k+1) = z_smoothed_c(k);
            eta_smoothed_c(k+1) = eta_smoothed_c(k);
            
            z_smoothed_l(k+1) = z_smoothed_l(k);
            eta_smoothed_l(k+1) = eta_smoothed_l(k);
            
        end
        
        
    end
    
    
end

%% Applying the Batch-State Space Model on the Attentional Marker Outputs

outer_EM_batch = 20;
inner_EM_batch = 20;

rho_d_l = rho_d_0_l;
mu_d_l = mu_d_0_l;
rho_d_c = rho_d_0_c;
mu_d_c = mu_d_0_c;

% Kalman filtering and smoothing variables
z_k_k_c = zeros(K+1,1);
z_k_k_1_c = zeros(K+1,1);
sig_k_k_c = zeros(K+1,1);
sig_k_k_1_c = zeros(K+1,1);
z_k_k_l = zeros(K+1,1);
z_k_k_1_l = zeros(K+1,1);
sig_k_k_l = zeros(K+1,1);
sig_k_k_1_l = zeros(K+1,1);

z_k_K_c = zeros(K+1,1);
sig_k_K_c = zeros(K+1,1);
z_k_K_l = zeros(K+1,1);
sig_k_K_l = zeros(K+1,1);

S_c = zeros(K,1);
S_l = zeros(K,1);

% batch state-space model outputs for the two attentional markers
z_batch_c = zeros(K,1);
eta_batch_c = 0.3*ones(K,1);
z_batch_l = zeros(K,1);
eta_batch_l = 0.3*ones(K,1);

% outer EM
for i = 1:outer_EM_batch
    
    % calculating epsilon_k's in the current iteration (E-Step)
            
    P_11_c = (1./c1)*sqrt(rho_d_c(1)).*exp(-0.5*rho_d_c(1)*(log(c1)-mu_d_c(1)).^2);
    P_12_c = (1./c1)*sqrt(rho_d_c(2)).*exp(-0.5*rho_d_c(2)*(log(c1)-mu_d_c(2)).^2);
    P_21_c = (1./c2)*sqrt(rho_d_c(2)).*exp(-0.5*rho_d_c(2)*(log(c2)-mu_d_c(2)).^2);
    P_22_c = (1./c2)*sqrt(rho_d_c(1)).*exp(-0.5*rho_d_c(1)*(log(c2)-mu_d_c(1)).^2);

    P_11_l = (1./m1)*sqrt(rho_d_l(1)).*exp(-0.5*rho_d_l(1)*(log(m1)-mu_d_l(1)).^2);
    P_12_l = (1./m1)*sqrt(rho_d_l(2)).*exp(-0.5*rho_d_l(2)*(log(m1)-mu_d_l(2)).^2);
    P_21_l = (1./m2)*sqrt(rho_d_l(2)).*exp(-0.5*rho_d_l(2)*(log(m2)-mu_d_l(2)).^2);
    P_22_l = (1./m2)*sqrt(rho_d_l(1)).*exp(-0.5*rho_d_l(1)*(log(m2)-mu_d_l(1)).^2);

    p_c = squeeze(1./(1+exp(-z_batch_c)));
    p_l = squeeze(1./(1+exp(-z_batch_l)));
    
    E_c = (p_c.*P_11_c.*P_21_c)./(p_c.*P_11_c.*P_21_c+(1-p_c).*P_12_c.*P_22_c);
    E_l = (p_l.*P_11_l.*P_21_l)./(p_l.*P_11_l.*P_21_l+(1-p_l).*P_12_l.*P_22_l);
            
    % prior update
    
    mu_d_c(1) = ( sum(E_c.*log(c1)+(1-E_c).*log(c2)) + K*mu_0_c(1) )/(2*K);
    mu_d_c(2) = ( sum(E_c.*log(c2)+(1-E_c).*log(c1)) + K*mu_0_c(2) )/(2*K);
    rho_d_c(1) = (2*K*alpha_0_c(1))/( sum( E_c.*((log(c1)-mu_d_c(1)).^2) + (1-E_c).*((log(c2)-mu_d_c(1)).^2) ) + K*(2*beta_0_c(1)+(mu_d_c(1)-mu_0_c(1)).^2) );
    rho_d_c(2) = (2*K*alpha_0_c(2))/( sum( E_c.*((log(c2)-mu_d_c(2)).^2) + (1-E_c).*((log(c1)-mu_d_c(2)).^2) ) + K*(2*beta_0_c(2)+(mu_d_c(2)-mu_0_c(2)).^2) );

    mu_d_l(1) = ( sum(E_l.*log(m1)+(1-E_l).*log(m2)) + K*mu_0_l(1) )/(2*K);
    mu_d_l(2) = ( sum(E_l.*log(m2)+(1-E_l).*log(m1)) + K*mu_0_l(2) )/(2*K);
    rho_d_l(1) = (2*K*alpha_0_l(1))/( sum( E_l.*((log(m1)-mu_d_l(1)).^2) + (1-E_l).*((log(m2)-mu_d_l(1)).^2) ) + K*(2*beta_0_l(1)+(mu_d_l(1)-mu_0_l(1)).^2) );
    rho_d_l(2) = (2*K*alpha_0_l(2))/( sum( E_l.*((log(m2)-mu_d_l(2)).^2) + (1-E_l).*((log(m1)-mu_d_l(2)).^2) ) + K*(2*beta_0_l(2)+(mu_d_l(2)-mu_0_l(2)).^2) );

    % inner EM for updating z's and eta's (M-Step)
            
    for j = 1:inner_EM_batch

        % Filtering
        for kk = 2:K+1

            z_k_k_1_c(kk) = lambda_state*z_k_k_c(kk-1);
            sig_k_k_1_c(kk) = lambda_state^2*sig_k_k_c(kk-1) + eta_batch_c(kk-1);
            z_k_k_1_l(kk) = lambda_state*z_k_k_l(kk-1);
            sig_k_k_1_l(kk) = lambda_state^2*sig_k_k_l(kk-1) + eta_batch_l(kk-1);

            % Newton's Algorithm
            for m=1:Newton_iter
                z_k_k_c(kk) = z_k_k_c(kk) - (z_k_k_c(kk) - z_k_k_1_c(kk) - sig_k_k_1_c(kk)*(E_c(kk-1) - exp(z_k_k_c(kk))/(1+exp(z_k_k_c(kk))))) / (1 + sig_k_k_1_c(kk)*exp(z_k_k_c(kk))/((1+exp(z_k_k_c(kk)))^2));
                z_k_k_l(kk) = z_k_k_l(kk) - (z_k_k_l(kk) - z_k_k_1_l(kk) - sig_k_k_1_l(kk)*(E_l(kk-1) - exp(z_k_k_l(kk))/(1+exp(z_k_k_l(kk))))) / (1 + sig_k_k_1_l(kk)*exp(z_k_k_l(kk))/((1+exp(z_k_k_l(kk)))^2));
            end

            sig_k_k_c(kk) = 1 / (1/sig_k_k_1_c(kk) + exp(z_k_k_c(kk))/((1+exp(z_k_k_c(kk)))^2));
            sig_k_k_l(kk) = 1 / (1/sig_k_k_1_l(kk) + exp(z_k_k_l(kk))/((1+exp(z_k_k_l(kk)))^2));

        end

        % Smoothing
        z_k_K_c(K+1) = z_k_k_c(K+1);
        sig_k_K_c(K+1) = sig_k_K_c(K+1);
        z_k_K_l(K+1) = z_k_k_l(K+1);
        sig_k_K_l(K+1) = sig_k_K_l(K+1);

        for kk = K:-1:1

            S_c(kk) = sig_k_k_c(kk)*lambda_state/sig_k_k_1_c(kk+1);
            z_k_K_c(kk) = z_k_k_c(kk) + S_c(kk)*(z_k_K_c(kk+1) - z_k_k_1_c(kk+1));
            sig_k_K_c(kk) = sig_k_k_c(kk) + S_c(kk)^2*(sig_k_K_c(kk+1) - sig_k_k_1_c(kk+1));

            S_l(kk) = sig_k_k_l(kk)*lambda_state/sig_k_k_1_l(kk+1);
            z_k_K_l(kk) = z_k_k_l(kk) + S_l(kk)*(z_k_K_l(kk+1) - z_k_k_1_l(kk+1));
            sig_k_K_l(kk) = sig_k_k_l(kk) + S_l(kk)^2*(sig_k_K_l(kk+1) - sig_k_k_1_l(kk+1));

        end

        z_k_k_c(1) = z_k_K_c(1);
        sig_k_k_c(1) = sig_k_K_c(1);

        z_k_k_l(1) = z_k_K_l(1);
        sig_k_k_l(1) = sig_k_K_l(1);

        % update the eta's
        eta_batch_c = ( (z_k_K_c(2:end)-z_k_K_c(1:end-1)).^2+sig_k_K_c(2:end)+sig_k_K_c(1:end-1)-2*sig_k_K_c(2:end).*S_c+2*b_0 )/(1+2*(a_0+1));
        eta_batch_l = ( (z_k_K_l(2:end)-z_k_K_l(1:end-1)).^2+sig_k_K_l(2:end)+sig_k_K_l(1:end-1)-2*sig_k_K_l(2:end).*S_l+2*b_0 )/(1+2*(a_0+1));

    end
    
    % update the z's
    z_batch_c = z_k_K_c(2:end);
    z_batch_l = z_k_K_l(2:end);
    
end

%% Plotting the Results

lim1 = 0.4*max(max(abs([Dec1(2:end,ceil(8*fs/W):end) Dec1(2:end,ceil(8*fs/W):end)])));
fig = figure('pos',[100 100 800 600]);
subplot(2,1,1)
imagesc((1:K)*W/fs,(0:L-1)/fs,Dec1(2:end,:),[-lim1,lim1])
colorbar;
title('estimated decoder for speaker 1')
ylabel('decoder lag (s)')
xlabel('trial time (s)')
subplot(2,1,2)
imagesc((1:K)*W/fs,(0:L-1)/fs,Dec2(2:end,:),[-lim1,lim1])
colorbar;
title('estimated decoder for speaker 2')
ylabel('decoder lag (s)')
xlabel('trial time (s)')

figure('pos',[100 100 1000 600]);

subplot(3,1,1)
plot((1:K)*W/fs,m1,'g','LineWidth',1.5);
hold on;
plot((1:K)*W/fs,m2,'r','LineWidth',1.5);
hold off;
legend('speaker 1','speaker 2','Location','southeast');
xlabel('time (s)')
lim1 = max(max(abs([m1(ceil(5*fs/W):end); m2(ceil(5*fs/W):end)])));
ylim([0, lim1]);
xlim([0 60]);
title('l_1-based Attentional Marker Output for Speakers 1 and 2');

subplot(3,1,2)
plot((1:K)*W/fs,1./(1+exp(-z_batch_l)),'b','LineWidth',1.5);
hold on;
plot((1:K)*W/fs,1./(1+exp(-z_batch_l-c0*sqrt(eta_batch_l))),'r-.','LineWidth',1.5);
plot((1:K)*W/fs,1./(1+exp(-z_batch_l+c0*sqrt(eta_batch_l))),'r-.','LineWidth',1.5);
plot((1:K)*W/fs,0.5*ones(K,1),'k--','LineWidth',1.5);
hold off;
xlabel('time (s)')
xlim([0 60]);
ylim([0,1]);
title('State-Space Output (Batch-Mode)');

subplot(3,1,3)
plot((1:K)*W/fs,1./(1+exp(-z_dyn_l)),'b','LineWidth',1.5);
hold on;
plot((1:K)*W/fs,1./(1+exp(-z_dyn_l-c0*sqrt(eta_dyn_l))),'r-.','LineWidth',1.5);
plot((1:K)*W/fs,1./(1+exp(-z_dyn_l+c0*sqrt(eta_dyn_l))),'r-.','LineWidth',1.5);
plot((1:K)*W/fs,0.5*ones(K,1),'k--','LineWidth',1.5);
hold off;
xlabel('time (s)')
ylim([0 1]);
xlim([0 60]);
title('State-Space Output (Dynamic Version)');

figure('pos',[100 100 1000 600]);

subplot(3,1,1)
plot((1:K)*W/fs,c1,'g','LineWidth',1.13);
hold on;
plot((1:K)*W/fs,c2,'r','LineWidth',1.13);
hold off;
legend('speaker 1','speaker 2','Location','southeast');
xlabel('time (s)')
xlim([0 60]);
title('Correlation-based Attentional Marker Output for Speakers 1 and 2');

subplot(3,1,2)
plot((1:K)*W/fs,1./(1+exp(-z_batch_c)),'b','LineWidth',1.5);
hold on;
plot((1:K)*W/fs,1./(1+exp(-z_batch_c-c0*sqrt(eta_batch_c))),'r-.','LineWidth',1.5);
plot((1:K)*W/fs,1./(1+exp(-z_batch_c+c0*sqrt(eta_batch_c))),'r-.','LineWidth',1.5);
plot((1:K)*W/fs,0.5*ones(K,1),'k--','LineWidth',1.5);
hold off;
xlabel('time (s)')
ylim([0 1]);
xlim([0 60]);
title('State-Space Output (Batch-Mode)');

subplot(3,1,3)
plot((1:K)*W/fs,1./(1+exp(-z_dyn_c)),'b','LineWidth',1.5);
hold on;
plot((1:K)*W/fs,1./(1+exp(-z_dyn_c-c0*sqrt(eta_dyn_c))),'r-.','LineWidth',1.5);
plot((1:K)*W/fs,1./(1+exp(-z_dyn_c+c0*sqrt(eta_dyn_c))),'r-.','LineWidth',1.5);
plot((1:K)*W/fs,0.5*ones(K,1),'k--','LineWidth',1.5);
hold off;
xlabel('time (s)')
ylim([0 1]);
xlim([0 60]);
title('State-Space Output (Dynamic Version)');